
/**
 * Method GET
 * API Painel WEB - https://softwork.painelweb.com.br/api/pessoas/getById
 * 
 * Recupera os dasos de Pessoa 
 */
let urlApi = '{{ getenv("API_URL")}}'
let id = $('input[name="id"]').val()
let alert = "Ainda faltam dados para finalizar seu cadastro, preencha os campos marcados em vermelho!"
$.ajax({
    type: 'get',
    contentType: "application/json; charset=utf-8",
    dataType: 'json',
    url: `http://painel.softwork.com.br/api/pessoas/getById/${id}`,
  })
  .done(function (dados) {
    $('input[name="nome"]').val(dados.nome)
    $('#welcome').html(dados.nome)
    $('#email').val(dados.email)
    if (dados.celular == "()  -") {
      $('input[name="celular"]').addClass("is-invalid")
      $('input[name="celular"]').mask('(99)99999-9999')
      $('#alert').html(alert)

    } else {
      $('#celular').val(dados.celular)
    }
    $('#logradouro').val(dados.logradouro)
    if (!dados.numero) {
      $('input[name="numero"]').addClass("is-invalid")
      $('#alert').html(alert)

    } else {
      $('#numero').val(dados.numero)
    }
    $('#complemento').val(dados.complemento)
    $('#cep').val(dados.cep)
    $('#bairro').val(dados.bairro)
    $('#cidade').val(dados.cidade)
    $('#uf').val(dados.uf)
  });