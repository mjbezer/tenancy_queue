
$.ajax({
    type:'get',		
    contentType: "application/json; charset=utf-8",
    dataType: 'json',	
    url: '/categorias/getAll'+location.search,
    })
    .done(function( dados ) {
        let html ='<option value="">Escolha uma categoria</option>'
        console.log(dados)
        dados.forEach(function(categoria, key){
            html+=`
            <option value = "${categoria.id}">${categoria.descricao}</option>
            `
        });
        if (dados.length > 0){
            $('#categorias').html(html)
        }else{
                swal({ 
                    title: 'CUIDADO!',
                     showCancelButton: true,
                     confirmButtonText: 'Sim, desejo incluir !',
                     cancelButtonText: 'Cancelar',
                     text: 'Para registar um serviço é necessário possuir ao menos uma categoria e sub-categoria cadastradas.',
                     type: 'warning',
                     confirmButtonColor: '#F54400',
                     showLoaderOnConfirm: true,
                     preConfirm: ()=>{
                        window.location.href ='/categorias/create'
                     }})
            } 
});

$('#categorias').change(function(){
    let categoria_id = $('#categorias').val();
    $.ajax({
    type:'get',		
    contentType: "application/json; charset=utf-8",
    dataType: 'json',	
    url: `/sub_categorias/getByCategory/${categoria_id}`+location.search,
    })
    .done(function( dados ) {
        let html ='<option value="">Escolha uma sub categoria</option>'
        console.log(dados)
        dados.forEach(function(sub_categoria, key){
            html+=`
            <option value = "${sub_categoria.id}">${sub_categoria.descricao}</option>
            `
        });
        $('#sub_categorias').html(html)
});
    


})
